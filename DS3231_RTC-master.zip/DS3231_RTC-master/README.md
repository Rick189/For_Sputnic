DS3231_RTC
==========

Firmware to control the DS3231 RTC IC from Maxim
